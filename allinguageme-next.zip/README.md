
# AllLinguageme (Landing + Waitlist)

Deploy på Vercel:
1) Opprett nytt prosjekt og last opp denne ZIP-filen.
2) Aktiver Vercel KV (Storage) og sett miljøvariablene:
   - KV_URL
   - KV_REST_API_URL
   - KV_REST_API_TOKEN
   - KV_REST_API_READ_ONLY_TOKEN
3) Deploy. Skjemaet på forsiden lagrer e-post i KV.

Lokal utvikling (valgfritt):
- npm install
- npm run dev
