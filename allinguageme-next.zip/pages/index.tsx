
import Head from 'next/head'
import { useState } from 'react'
import { Sparkles, Shield, Globe2, Check, ChevronRight } from 'lucide-react'

export default function Home() {
  const [email, setEmail] = useState('');
  const [saved, setSaved] = useState(false);
  const [status, setStatus] = useState<string | null>(null);

  async function onJoin(e: any) {
    e.preventDefault();
    if (!/.+@.+\..+/.test(email)) { alert('Skriv en gyldig e-post.'); return; }
    setStatus('sender');
    try {
      const res = await fetch('/api/waitlist', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ email, ts: new Date().toISOString() })
      });
      if (!res.ok) throw new Error(await res.text());
      setSaved(true);
      setEmail('');
      setStatus('ok');
    } catch (e:any) {
      setStatus('feil');
      alert('Kunne ikke lagre på server. Prøv igjen senere.');
    }
  }

  return (
    <>
      <Head>
        <title>AllLinguageme</title>
      </Head>

      <header className="sticky top-0 z-20 bg-white/80 backdrop-blur border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="font-semibold tracking-tight text-lg text-[var(--blue)]">AllLinguageme</div>
          <div className="flex items-center gap-2">
            <a className="px-3 py-2 rounded hover:bg-black/5" href="#features">Funksjoner</a>
            <a className="px-3 py-2 rounded hover:bg-black/5" href="#pricing">Pris</a>
            <a className="px-3 py-2 rounded hover:bg-black/5" href="#how">Hvordan</a>
          </div>
        </div>
      </header>

      <main>
        <section className="max-w-6xl mx-auto px-4 py-16 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-semibold leading-tight text-[var(--ink)]">
              Lær språk – seriøst. <span className="text-[var(--coral)]">Uten å kjede deg.</span>
            </h1>
            <p className="mt-4 text-lg text-gray-600">
              AllLinguageme er din AI-mentor som trener deg i ekte samtaler – med uttale, kultur og personlighet.
            </p>
            <div className="mt-6 flex flex-wrap gap-3 items-center">
              <a href="#pricing" className="px-5 py-3 rounded text-white" style={{background:'var(--blue)'}}>
                <span className="inline-flex items-center gap-2"><Sparkles size={18}/>Start gratis</span>
              </a>
              <a href="#demo" className="px-5 py-3 rounded border">Se demo</a>
              <form onSubmit={onJoin} className="w-full md:w-auto md:flex md:items-center gap-2">
                <input type="email" className="mt-3 md:mt-0 md:w-72 px-3 py-3 rounded border w-full"
                  placeholder="Din e-post for tidlig tilgang" value={email} onChange={e=>setEmail(e.target.value)}/>
                <button className="mt-2 md:mt-0 px-5 py-3 rounded text-white" style={{background:'var(--coral)'}}>
                  {status==='sender' ? 'Sender…' : 'Bli med på ventelisten'}
                </button>
              </form>
            </div>
            {saved && (<div className="mt-3 text-sm bg-green-50 border border-green-200 text-green-700 px-3 py-2 rounded-lg">
              Takk! Du står på ventelisten. Vi sender oppdateringer snart.
            </div>)}
            <div className="mt-6 flex items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-2"><Shield size={16}/>Personvern i fokus</div>
              <div className="flex items-center gap-2"><Globe2 size={16}/>20+ språk</div>
            </div>
          </div>

          <div id="demo" className="border rounded-xl p-4 shadow-md bg-white">
            <div className="text-sm font-medium">Live demo – AI-samtale</div>
            <div className="p-3 rounded-xl bg-gray-100 text-sm mt-2">
              <div className="font-medium">AI (Filippinsk venn):</div>
              <p>Kamusta! Anong pangalan mo? (Hei! Hva heter du?)</p>
            </div>
            <div className="flex gap-2 mt-3">
              <input placeholder="Skriv svaret ditt…" className="px-3 py-3 rounded border w-full" />
              <button className="px-4 py-3 rounded border">Send</button>
            </div>
            <div className="text-xs text-gray-500 mt-2">Tips: Svar «Ako si [navn].»</div>
          </div>
        </section>

        <section id="how" className="py-16 bg-white">
          <div className="max-w-6xl mx-auto px-4">
            <h2 className="text-3xl font-semibold">Hvordan det fungerer</h2>
            <div className="mt-8 grid md:grid-cols-3 gap-6">
              {[
                {t:'Velg mål og språk', d:'Reise, jobb eller flyt – appen tilpasser læringsløpet ditt.'},
                {t:'Snakk med AI-mentorer', d:'Realistiske roller trener deg i ekte dialoger – og retter deg vennlig.'},
                {t:'Målbar fremgang', d:'Uttalepoeng, nivåer og kulturforståelse, ikke bare gloser.'},
              ].map((x,i)=>(
                <div key={i} className="border rounded-xl p-4">
                  <div className="text-lg font-semibold">{i+1}. {x.t}</div>
                  <div className="text-sm text-gray-600 mt-1">{x.d}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="features" className="py-16">
          <div className="max-w-6xl mx-auto px-4">
            <h2 className="text-3xl font-semibold">Det du får</h2>
            <div className="mt-8 grid md:grid-cols-2 gap-6">
              <ul className="space-y-3 text-sm">
                {[
                  'AI-samtaler med personlighet (barista, kollega, venn)',
                  'Uttaletrening og tilbakemelding i sanntid',
                  'Dynamiske leksjoner basert på hvordan du lærer',
                  'Spaced repetition-flashcards',
                  'Fokus på kultur, tone og naturlige uttrykk',
                ].map((t,i)=>(
                  <li key={i} className="flex items-start gap-2"><Check size={16} className="mt-1 text-green-600"/>{t}</li>
                ))}
              </ul>
              <div className="border rounded-xl p-4">
                <div className="text-lg font-semibold">Mini-demo: Dagens frase</div>
                <div className="mt-2 text-sm">“Magkano ito?” – Hvor mye koster dette?</div>
                <div className="mt-1 text-sm">“¿Cuánto cuesta?” – Hvor mye koster det?</div>
                <div className="mt-1 text-sm">“How much is this?”</div>
              </div>
            </div>
          </div>
        </section>

        <section id="pricing" className="py-16 bg-white">
          <div className="max-w-6xl mx-auto px-4">
            <h2 className="text-3xl font-semibold">Pris</h2>
            <div className="mt-8 grid md:grid-cols-3 gap-6">
              {[
                {title:'Gratis', features:['10 meldinger/dag','Grunnleggende leksjoner','Flashcards'], cta:'Start gratis', style:''},
                {title:'Premium', features:['Ubegrenset AI-samtale','Avansert uttalescore','Temakurs + kulturmoduler'], cta:'Oppgrader', style:'border-[var(--coral)]'},
                {title:'Bedrift', features:['Teamdashbord og rapporter','Skreddersydde kurs','Volumrabatter'], cta:'Kontakt salg', style:''},
              ].map((p,idx)=>(
                <div key={idx} className={"border rounded-xl p-4 " + (idx===1 ? "shadow-lg border-[var(--coral)] relative" : "")}>
                  {idx===1 && <div className="absolute -top-3 right-4 rounded-full px-3 py-1 text-xs text-white" style={{background:'var(--coral)'}}>Mest valgt</div>}
                  <div className="text-lg font-semibold">{p.title}</div>
                  {idx===1 && <div className="text-2xl font-semibold mt-1">99 kr/mnd</div>}
                  <ul className="text-sm space-y-2 mt-3">
                    {p.features.map((f,i)=>(<li key={i} className="flex items-start gap-2"><Check size={16} className="mt-1 text-green-600"/>{f}</li>))}
                  </ul>
                  <button className={"w-full mt-3 px-4 py-3 rounded " + (idx===1 ? "text-white" : "border")} style={idx===1 ? {background:'var(--blue)'} : {}}> {p.cta} </button>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 bg-[var(--sand)] text-center">
          <h3 className="text-2xl font-semibold">Klar for å snakke som en lokal?</h3>
          <p className="mt-2 text-gray-600">Kom i gang gratis på under ett minutt.</p>
          <div className="mt-6 flex justify-center">
            <a href="#pricing" className="px-6 py-3 rounded text-white" style={{background:'var(--coral)'}}>
              Kom i gang <ChevronRight size={16} className="inline ml-1" />
            </a>
          </div>
        </section>
      </main>

      <footer className="py-8 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} AllLinguageme • Personvern • Vilkår
      </footer>
    </>
  )
}
