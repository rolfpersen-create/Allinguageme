
import type { NextApiRequest, NextApiResponse } from 'next';
import { kv } from '@vercel/kv';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method Not Allowed' });
  }
  try {
    const { email, utm = '', ts = new Date().toISOString() } = (req.body || {}) as { email?: string; utm?: string; ts?: string };
    if (!email || !/^([^@\s]+)@([^@\s]+)\.([^@\s]+)$/.test(email)) {
      return res.status(400).json({ error: 'Invalid email' });
    }
    const key = `waitlist:${email.toLowerCase()}`;
    await kv.hset(key, { email, utm, ts });
    await kv.incr('metrics:waitlist_total');
    return res.status(200).json({ ok: true });
  } catch (err: any) {
    console.error('waitlist error', err);
    return res.status(500).json({ error: 'Server error' });
  }
}
